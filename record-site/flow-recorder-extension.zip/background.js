import { adoptRecordingNavigationTarget, adoptRecordingTabOnCreate, ensureRecordingContentScript, openEditorTab } from './navigation.js';
import { APP_ORIGINS, DEFAULT_APP_ORIGIN, LOCAL_APP_ORIGIN } from './config.js';

const API = DEFAULT_APP_ORIGIN;
const ALLOWED_API_ORIGINS = APP_ORIGINS;
const SCREENSHOT_INTERVAL_MS = 550;
let lastScreenshot = null;
let lastScreenshotAt = 0;
let lastScreenshotTabId = null;
let screenshotInFlight = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'captureAndSend') {
    captureAndSend(message.payload || {}, sender).then(sendResponse);
    return true;
  }

  if (message?.type === 'apiRequest') {
    apiRequest(message.request || {}).then(sendResponse);
    return true;
  }

  if (message?.type === 'getRecordingContext') {
    getRecordingContext(sender).then(sendResponse);
    return true;
  }

  if (message?.type === 'setApiOrigin') {
    setApiOrigin(message.origin).then(sendResponse);
    return true;
  }

  if (message?.type === 'rememberTargetingClaim') {
    rememberTargetingClaim(sender, message.token).then(sendResponse);
    return true;
  }

  if (message?.type === 'clearTargetingClaim') {
    clearTargetingClaim(sender).then(sendResponse);
    return true;
  }

  if (message?.type === 'openEditor') {
    openEditorTab(chrome, message.sessionId, message.stepId).then(sendResponse);
    return true;
  }

  if (message?.type === 'completeTargeting') {
    completeTargetingAndSend(message.payload || {}, sender).then(sendResponse);
    return true;
  }

  if (message?.type === 'listRecordableTabs') {
    listRecordableTabs(sender).then(sendResponse);
    return true;
  }

  if (message?.type === 'startRecordingTab') {
    startRecordingTab(sender, message.tabId, message.title, message.ownerId).then(sendResponse);
    return true;
  }

  if (message?.type === 'recaptureStep') {
    recaptureStep(sender, message.tabId, message.sessionId, message.stepId).then(sendResponse);
    return true;
  }
});

async function listRecordableTabs(sender) {
  const apiOrigin = getAllowedOrigin(sender.tab?.url) || await getApiOrigin();
  if (!sender.tab?.url?.startsWith(`${apiOrigin}/`)) return { ok: false, error: 'unauthorized_page' };
  const tabs = await chrome.tabs.query({ windowId: sender.tab.windowId });
  return {
    ok: true,
    tabs: tabs.filter((tab) => /^https?:\/\//.test(tab.url || '') && !tab.url.startsWith(`${apiOrigin}/`)).map((tab) => ({ id: tab.id, title: tab.title || tab.url, url: tab.url, active: Boolean(tab.active) }))
  };
}

async function startRecordingTab(sender, tabId, requestedTitle, ownerId = '') {
  const apiOrigin = getAllowedOrigin(sender.tab?.url) || await getApiOrigin();
  if (!sender.tab?.url?.startsWith(`${apiOrigin}/`)) return { ok: false, error: 'unauthorized_page' };
  if (!Number.isInteger(tabId)) return { ok: false, error: 'invalid_tab' };
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || tab.windowId !== sender.tab.windowId || !/^https?:\/\//.test(tab.url || '') || tab.url.startsWith(`${apiOrigin}/`)) return { ok: false, error: 'tab_not_recordable' };
  if (!(await ensureRecordingContentScript(chrome, tabId))) return { ok: false, error: 'cannot_connect_tab' };
  const previous = await chrome.storage.local.get(['recording', 'sessionId']);
  if (previous.recording && previous.sessionId) await apiRequest({ path: `/api/session/${encodeURIComponent(previous.sessionId)}/state`, method: 'POST', body: { status: 'stopped' } });
  const title = String(requestedTitle || '').trim().slice(0, 120) || `流程_${new Date().toLocaleString()}`;
  const started = await apiRequest({ path: '/api/session/start', method: 'POST', body: { title, startUrl: tab.url, ownerId } });
  if (!started.ok || !started.data?.sessionId) return started;
  await chrome.storage.local.set({ recording: true, paused: false, sessionId: started.data.sessionId, title, startedAt: Date.now(), recordingTabId: tabId });
  await chrome.tabs.update(tabId, { active: true });
  try { await chrome.tabs.sendMessage(tabId, { type: 'RECORDER_STATE' }); } catch {}
  return { ok: true, sessionId: started.data.sessionId, tabId };
}

async function recaptureStep(sender, tabId, sessionId, stepId) {
  const apiOrigin = getAllowedOrigin(sender.tab?.url) || await getApiOrigin();
  if (!sender.tab?.url?.startsWith(`${apiOrigin}/`)) return { ok: false, error: 'unauthorized_page' };
  if (!Number.isInteger(tabId) || !/^[a-zA-Z0-9_-]{8,160}$/.test(String(sessionId)) || !/^[a-zA-Z0-9_-]{8,160}$/.test(String(stepId))) {
    return { ok: false, error: 'invalid_recapture_target' };
  }
  const targetTab = await chrome.tabs.get(tabId).catch(() => null);
  if (!targetTab || targetTab.windowId !== sender.tab.windowId || !/^https?:\/\//.test(targetTab.url || '') || targetTab.url.startsWith(`${apiOrigin}/`)) {
    return { ok: false, error: 'tab_not_recordable' };
  }
  if (!(await ensureRecordingContentScript(chrome, tabId))) return { ok: false, error: 'cannot_connect_tab' };
  const editorTabId = sender.tab.id;
  try {
    await chrome.tabs.update(tabId, { active: true });
    await chrome.tabs.sendMessage(tabId, { type: 'PREPARE_FLOW_SCREENSHOT' });
    const screenshot = await getScreenshot(targetTab.windowId, tabId, true);
    if (!screenshot.blob) return { ok: false, error: screenshot.warning || 'screenshot_failed' };
    const form = new FormData();
    form.append('screenshot', screenshot.blob, 'recaptured.png');
    const response = await fetch(`${apiOrigin}/api/session/${encodeURIComponent(sessionId)}/step/${encodeURIComponent(stepId)}/image`, {
      method: 'POST',
      body: form
    });
    const data = await readResponse(response);
    return response.ok ? { ok: true, data } : { ok: false, error: data.error || `http_${response.status}` };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  } finally {
    try { await chrome.tabs.sendMessage(tabId, { type: 'FINISH_FLOW_SCREENSHOT' }); } catch {}
    if (editorTabId) {
      try { await chrome.tabs.update(editorTabId, { active: true }); } catch {}
    }
  }
}

chrome.webNavigation.onHistoryStateUpdated.addListener(notifyNavigation);
chrome.webNavigation.onReferenceFragmentUpdated.addListener(notifyNavigation);
chrome.webNavigation.onCreatedNavigationTarget.addListener((details) => {
  void adoptRecordingNavigationTarget(chrome, details);
});
chrome.tabs.onCreated.addListener((tab) => {
  void adoptRecordingTabOnCreate(chrome, tab);
});

async function captureAndSend(payload, sender) {
  try {
    const state = await chrome.storage.local.get(['recording', 'paused', 'sessionId', 'recordingTabId']);
    if (!state.recording || state.paused || !state.sessionId) {
      return { ok: false, error: 'not_recording' };
    }
    if (!sender.tab?.windowId) return { ok: false, error: 'no_tab' };
    if (sender.tab.id !== state.recordingTabId) return { ok: false, error: 'wrong_recording_tab' };

    const screenshot = payload.type === 'navigation'
      ? { blob: null, reused: false, warning: '' }
      : await getScreenshot(sender.tab.windowId, sender.tab.id);
    const form = new FormData();
    appendFields(form, payload, sender.tab.url || '');
    if (screenshot.blob) form.append('screenshot', screenshot.blob, 'shot.png');

    const response = await fetch(`${await getApiOrigin()}/api/session/${encodeURIComponent(state.sessionId)}/event`, {
      method: 'POST',
      body: form
    });
    const data = await readResponse(response);
    if (!response.ok) return { ok: false, error: data.error || `http_${response.status}` };
    return {
      ok: true,
      data,
      warning: screenshot.warning || undefined,
      hasScreenshot: Boolean(screenshot.blob),
      screenshotReused: screenshot.reused
    };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

async function completeTargetingAndSend(payload, sender) {
  try {
    if (!sender.tab?.windowId) return { ok: false, error: 'no_tab' };
    const screenshot = await getScreenshot(sender.tab.windowId, sender.tab.id, true);
    const form = new FormData();
    form.append('clientId', String(payload.clientId || ''));
    if (payload.locator) form.append('locator', JSON.stringify(payload.locator));
    if (payload.region) form.append('region', JSON.stringify(payload.region));
    form.append('label', String(payload.label || ''));
    if (screenshot.blob) form.append('screenshot', screenshot.blob, 'target.png');
    const response = await fetch(`${await getApiOrigin()}/api/targeting/complete`, { method: 'POST', body: form });
    const data = await readResponse(response);
    if (!response.ok) return { ok: false, error: data.error || `http_${response.status}` };
    return { ok: true, data, warning: screenshot.warning || undefined, hasScreenshot: Boolean(screenshot.blob) };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

async function getScreenshot(windowId, tabId, forceFresh = false) {
  if (!(await isActiveTab(windowId, tabId))) {
    return { blob: null, reused: false, warning: 'recording_tab_not_active' };
  }
  if (screenshotInFlight) {
    await screenshotInFlight;
    if (!forceFresh && lastScreenshot && lastScreenshotTabId === tabId) {
      return { blob: lastScreenshot, reused: true, warning: '' };
    }
  }

  if (!forceFresh && lastScreenshot && lastScreenshotTabId === tabId && Date.now() - lastScreenshotAt < SCREENSHOT_INTERVAL_MS) {
    return { blob: lastScreenshot, reused: true, warning: '' };
  }

  let warning = '';
  screenshotInFlight = (async () => {
    try {
      const waitMs = SCREENSHOT_INTERVAL_MS - (Date.now() - lastScreenshotAt);
      if (waitMs > 0) await new Promise((resolve) => setTimeout(resolve, waitMs));
      if (!(await isActiveTab(windowId, tabId))) throw new Error('recording_tab_not_active');
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
      if (!(await isActiveTab(windowId, tabId))) throw new Error('recording_tab_changed_during_capture');
      lastScreenshot = await (await fetch(dataUrl)).blob();
      lastScreenshotAt = Date.now();
      lastScreenshotTabId = tabId;
    } catch (error) {
      warning = String(error?.message || error);
    }
  })();
  await screenshotInFlight;
  screenshotInFlight = null;
  const captured = !warning && lastScreenshotTabId === tabId ? lastScreenshot : null;
  return { blob: captured, reused: false, warning };
}

async function isActiveTab(windowId, tabId) {
  const [active] = await chrome.tabs.query({ active: true, windowId });
  return active?.id === tabId;
}

async function apiRequest({ path, method = 'GET', body }) {
  try {
    if (typeof path !== 'string' || (!path.startsWith('/api/') && path !== '/health')) {
      return { ok: false, error: 'invalid_api_path' };
    }
    const options = { method };
    if (body !== undefined) {
      options.headers = { 'Content-Type': 'application/json' };
      options.body = JSON.stringify(body);
    }
    const response = await fetch(`${await getApiOrigin()}${path}`, options);
    const data = await readResponse(response);
    return response.ok
      ? { ok: true, data }
      : { ok: false, error: data.error || `http_${response.status}`, status: response.status };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

async function getApiOrigin() {
  await chrome.storage.local.set({ flowRecorderApiOrigin: LOCAL_APP_ORIGIN });
  return LOCAL_APP_ORIGIN;
}

function getAllowedOrigin(url) {
  try {
    const origin = new URL(url).origin;
    return ALLOWED_API_ORIGINS.has(origin) ? origin : '';
  } catch {
    return '';
  }
}

async function setApiOrigin(origin) {
  await chrome.storage.local.set({ flowRecorderApiOrigin: LOCAL_APP_ORIGIN });
  return { ok: true, origin: LOCAL_APP_ORIGIN };
}

async function getRecordingContext(sender) {
  const state = await chrome.storage.local.get(['recording', 'recordingTabId']);
  const claimKey = targetingClaimKey(sender.tab?.id);
  const claim = claimKey ? await chrome.storage.session.get(claimKey) : {};
  return {
    ok: true,
    tabId: sender.tab?.id || null,
    isRecordingTab: Boolean(state.recording && sender.tab?.id === state.recordingTabId),
    targetingClaimToken: claimKey ? claim[claimKey] || '' : ''
  };
}

async function rememberTargetingClaim(sender, token) {
  const key = targetingClaimKey(sender.tab?.id);
  if (!key || typeof token !== 'string' || !token.startsWith('target_')) return { ok: false };
  await chrome.storage.session.set({ [key]: token.slice(0, 160) });
  return { ok: true };
}

async function clearTargetingClaim(sender) {
  const key = targetingClaimKey(sender.tab?.id);
  if (key) await chrome.storage.session.remove(key);
  return { ok: true };
}

function targetingClaimKey(tabId) {
  return Number.isInteger(tabId) ? `targetingClaim:${tabId}` : '';
}

async function notifyNavigation(details) {
  if (details.frameId !== 0) return;
  const state = await chrome.storage.local.get(['recording', 'recordingTabId']);
  if (!state.recording || state.recordingTabId !== details.tabId) return;
  try {
    await chrome.tabs.sendMessage(details.tabId, { type: 'RECORDER_NAVIGATION', url: details.url });
  } catch {}
}

function appendFields(form, payload, fallbackUrl) {
  const fields = {
    eventId: payload.eventId || '',
    occurredAt: payload.occurredAt || new Date().toISOString(),
    elapsedMs: payload.elapsedMs || 0,
    type: payload.type || 'click',
    url: payload.url || fallbackUrl,
    locator: JSON.stringify(payload.locator || {}),
    label: payload.label || '',
    scrollHint: payload.scrollHint || '',
    value: payload.value || '',
    valuePolicy: payload.valuePolicy || 'none',
    sensitive: payload.sensitive ? 'true' : 'false',
    viewport: JSON.stringify(payload.viewport || {}),
    x: payload.x || 0,
    y: payload.y || 0
  };
  Object.entries(fields).forEach(([key, value]) => form.append(key, String(value)));
}

async function readResponse(response) {
  const type = response.headers.get('content-type') || '';
  return type.includes('application/json') ? response.json() : { text: await response.text() };
}
