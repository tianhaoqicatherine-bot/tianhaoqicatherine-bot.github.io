import { ensureRecordingContentScript } from './navigation.js';
import { APP_ORIGINS, DEFAULT_APP_ORIGIN, LOCAL_APP_ORIGIN } from './config.js';

const API = DEFAULT_APP_ORIGIN;
const ALLOWED_API_ORIGINS = APP_ORIGINS;
const titleInput = document.getElementById('title');
const statusEl = document.getElementById('status');
const diagnoseEl = document.getElementById('diagnose');
const themeToggle = document.getElementById('themeToggle');
const manifest = chrome.runtime.getManifest();
document.getElementById('appTitle').textContent = 'Flow Recorder';

let themeAnimationTimer;
function applyTheme(theme, animate = false) {
  const light = theme === 'light';
  document.body.classList.toggle('light-mode', light);
  themeToggle.textContent = light ? '☀️' : '🌙';
  themeToggle.title = light ? '切换到深色模式' : '切换到浅色模式';
  chrome.storage.local.set({ flowRecorderTheme: light ? 'light' : 'dark' });
  if (animate) {
    themeToggle.classList.remove('theme-changing');
    void themeToggle.offsetWidth;
    themeToggle.classList.add('theme-changing');
    clearTimeout(themeAnimationTimer);
    themeAnimationTimer = setTimeout(() => themeToggle.classList.remove('theme-changing'), 650);
  }
}

themeToggle.onclick = () => applyTheme(document.body.classList.contains('light-mode') ? 'dark' : 'light', true);

const isRecordableUrl = (url) => {
  if (!url) return { ok: false, reason: '无法获取当前页 URL' };
  const blocked = ['chrome://', 'edge://', 'about:', 'chrome-extension://', 'https://chrome.google.com/webstore'];
  if (blocked.some((prefix) => url.startsWith(prefix))) {
    return { ok: false, reason: '该页面受浏览器限制，无法录制' };
  }
  return { ok: true, reason: '当前页面可录制' };
};

document.getElementById('start').onclick = () => runAction(async () => {
  if (!(await checkServer())) throw new Error('本地服务未启动');
  const { tab, recordable } = await refreshDiagnose();
  if (!recordable) throw new Error('当前页不可录制');
  if (!tab?.id) throw new Error('无法确定当前标签页');
  if (!(await ensureRecordingContentScript(chrome, tab.id))) {
    throw new Error('无法连接当前页面，请刷新后重试');
  }

  const previous = await chrome.storage.local.get(['recording', 'sessionId']);
  if (previous.recording && previous.sessionId) {
    await requestJson(`/api/session/${encodeURIComponent(previous.sessionId)}/state`, {
      method: 'POST', body: { status: 'stopped' }
    });
  }

  const title = titleInput.value.trim() || `流程_${new Date().toLocaleString()}`;
  const data = await requestJson('/api/session/start', {
    method: 'POST', body: { title, startUrl: tab.url || '' }
  });
  const startedAt = Date.now();
  await chrome.storage.local.set({
    recording: true,
    paused: false,
    sessionId: data.sessionId,
    title,
    startedAt,
    recordingTabId: tab.id
  });
  await notifyActiveTab();
  statusEl.textContent = `录制中：${title}`;
});

document.getElementById('pause').onclick = () => changeRecordingState('paused');
document.getElementById('resume').onclick = () => changeRecordingState('recording');

async function changeRecordingState(status) {
  return runAction(async () => {
    const stored = await chrome.storage.local.get(['sessionId']);
    if (!stored.sessionId) throw new Error('当前没有录制会话');
    await requestJson(`/api/session/${encodeURIComponent(stored.sessionId)}/state`, {
      method: 'POST', body: { status }
    });
    await chrome.storage.local.set({ paused: status === 'paused', recording: true });
    await notifyActiveTab();
    statusEl.textContent = status === 'paused' ? '已暂停' : '录制中';
  });
}

async function refreshDiagnose() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const diagnosis = isRecordableUrl(tab?.url || '');
  diagnoseEl.textContent = diagnosis.reason;
  diagnoseEl.className = `small ${diagnosis.ok ? 'ok' : 'bad'}`;
  return { tab, recordable: diagnosis.ok };
}

async function checkServer() {
  try {
    const response = await fetch(`${await getApiOrigin()}/health`);
    return response.ok;
  } catch {
    return false;
  }
}

async function requestJson(path, { method = 'GET', body } = {}) {
  const options = { method };
  if (body !== undefined) {
    options.headers = { 'Content-Type': 'application/json' };
    options.body = JSON.stringify(body);
  }
  const response = await fetch(`${await getApiOrigin()}${path}`, options);
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

async function notifyActiveTab() {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!active?.id) return;
  try { await chrome.tabs.sendMessage(active.id, { type: 'RECORDER_STATE' }); } catch {}
}

function openEditor(sessionId) {
  void getApiOrigin().then((origin) => {
    const url = sessionId ? `${origin}/?sessionId=${encodeURIComponent(sessionId)}` : `${origin}/`;
    chrome.tabs.create({ url });
  });
}

async function getApiOrigin() {
  await chrome.storage.local.set({ flowRecorderApiOrigin: LOCAL_APP_ORIGIN });
  return LOCAL_APP_ORIGIN;
}

function getAllowedOrigin(url) {
  try {
    const origin = new URL(url).origin;
    return ALLOWED_API_ORIGINS.has(origin) ? origin : '';
  } catch {
    return '';
  }
}

async function runAction(action) {
  try {
    await action();
  } catch (error) {
    statusEl.textContent = `操作失败：${error.message || error}`;
    statusEl.className = 'small bad';
  }
}

(async function init() {
  const theme = await chrome.storage.local.get(['flowRecorderTheme']);
  applyTheme(theme.flowRecorderTheme || 'dark');
  if (!(await checkServer())) statusEl.textContent = 'Flow Recorder 服务未启动';
  const stored = await chrome.storage.local.get(['recording', 'paused', 'sessionId', 'title']);
  if (stored.recording) statusEl.textContent = stored.paused ? '已暂停' : `录制中：${stored.title || stored.sessionId}`;
  await refreshDiagnose();
})();
