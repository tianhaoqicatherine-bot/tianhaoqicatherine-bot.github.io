import { DEFAULT_APP_ORIGIN } from './config.js';

const EDITOR_ORIGIN = DEFAULT_APP_ORIGIN;

export async function openEditorTab(chromeApi, sessionId, stepId = '') {
  if (!sessionId) return { ok: false, error: 'missing_session_id' };
  try {
    const editorUrl = new URL(`${EDITOR_ORIGIN}/`);
    editorUrl.searchParams.set('sessionId', sessionId);
    if (stepId) editorUrl.searchParams.set('focusStep', stepId);
    const tabs = chromeApi.tabs.query ? await chromeApi.tabs.query({}) : [];
    const existing = tabs.find((tab) => {
      try {
        const url = new URL(tab.url || '');
        return url.origin === EDITOR_ORIGIN && url.searchParams.get('sessionId') === sessionId;
      } catch {
        return false;
      }
    });
    if (existing?.id) {
      await chromeApi.tabs.update(existing.id, { url: editorUrl.toString(), active: true });
      if (existing.windowId && chromeApi.windows?.update) await chromeApi.windows.update(existing.windowId, { focused: true });
      return { ok: true, tabId: existing.id };
    }
    const tab = await chromeApi.tabs.create({
      url: editorUrl.toString()
    });
    return { ok: true, tabId: tab?.id || null };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

export async function adoptRecordingTabOnCreate(chromeApi, tab) {
  return adoptRecordingTab(chromeApi, tab?.openerTabId, tab?.id);
}

export async function ensureRecordingContentScript(chromeApi, tabId) {
  if (!Number.isInteger(tabId)) return false;
  try {
    await chromeApi.tabs.sendMessage(tabId, { type: 'RECORDER_STATE' });
    return true;
  } catch {
    try {
      await chromeApi.scripting.executeScript({ target: { tabId }, files: ['claim.js', 'content.js'] });
      return true;
    } catch {
      return false;
    }
  }
}

export async function adoptRecordingNavigationTarget(chromeApi, details) {
  return adoptRecordingTab(chromeApi, details?.sourceTabId, details?.tabId);
}

async function adoptRecordingTab(chromeApi, sourceTabId, targetTabId) {
  if (!Number.isInteger(sourceTabId) || !Number.isInteger(targetTabId)) return false;
  const state = await chromeApi.storage.local.get(['recording', 'recordingTabId']);
  if (!state.recording || state.recordingTabId !== sourceTabId) return false;
  await chromeApi.storage.local.set({ recordingTabId: targetTabId });
  return true;
}
