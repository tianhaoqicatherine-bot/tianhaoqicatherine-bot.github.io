// This build intentionally talks only to the local Flow Recorder service.
export const LOCAL_APP_ORIGIN = 'http://127.0.0.1:3838';
export const DEFAULT_APP_ORIGIN = LOCAL_APP_ORIGIN;
export const APP_ORIGINS = new Set([LOCAL_APP_ORIGIN, 'http://localhost:3838']);
