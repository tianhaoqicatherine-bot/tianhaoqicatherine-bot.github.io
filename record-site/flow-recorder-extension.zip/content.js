const POS_KEY = 'flow_recorder_overlay_position';
const SENSITIVE_AUTOCOMPLETE = new Set([
  'current-password',
  'new-password',
  'one-time-code',
  'cc-number',
  'cc-csc'
]);

let state = { recording: false, paused: false, sessionId: null, title: '', startedAt: 0 };
let lastNavigationKey = '';
let activeGuide = null;
let activeTargeting = null;
let guidedElement = null;
let guidedRegion = null;
let guidePoll = null;
let captureUiLocks = 0;
let captureUiStyles = null;
let browserTabId = null;
let targetingClaimToken = globalThis.__flowTargetingClaimToken || '';
let sensitiveMaskLocks = 0;
let restoreSensitiveMask = null;
let guideAdvancePending = false;
let regionDragStart = null;
let targetingStateVersion = 0;
let targetingArmPromise = null;
let pendingTargetSelection = null;
let pendingScrollHint = '';
let lastRecordedScrollY = window.scrollY;
const dirtyFields = new WeakSet();
const skipNextChange = new WeakSet();

const recorder = createRecorderOverlay();
const guide = createGuideOverlay();
const targeting = createTargetingOverlay();
const pulseLayer = createPulseLayer();

setupRecorderDrag();
bindRecorderActions();
bindGuideActions();
targeting.cancel.addEventListener('click', cancelTargeting);
targeting.activate.addEventListener('click', handleTargetingPrimaryAction);
syncState();
startGuidePolling();

if (['http://127.0.0.1:3838', 'http://localhost:3838'].includes(location.origin)) {
  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'flow-recorder-page') return;
    const requestId = String(event.data.requestId || '');
    if (event.data.type === 'LIST_RECORDABLE_TABS') {
      const result = await sendRuntimeMessage({ type: 'listRecordableTabs' });
      window.postMessage({ source: 'flow-recorder-extension', type: 'RECORDABLE_TABS_RESULT', requestId, result }, location.origin);
    }
    if (event.data.type === 'START_RECORDING_TAB') {
      const result = await sendRuntimeMessage({ type: 'startRecordingTab', tabId: Number(event.data.tabId), title: String(event.data.title || ''), ownerId: String(event.data.ownerId || '') });
      window.postMessage({ source: 'flow-recorder-extension', type: 'START_RECORDING_RESULT', requestId, result }, location.origin);
    }
    if (event.data.type === 'SET_API_ORIGIN') {
      const result = await sendRuntimeMessage({ type: 'setApiOrigin', origin: location.origin });
      window.postMessage({ source: 'flow-recorder-extension', type: 'SET_API_ORIGIN_RESULT', requestId, result }, location.origin);
    }
    if (event.data.type === 'RECAPTURE_STEP') {
      const result = await sendRuntimeMessage({
        type: 'recaptureStep',
        tabId: Number(event.data.tabId),
        sessionId: String(event.data.sessionId || ''),
        stepId: String(event.data.stepId || '')
      });
      window.postMessage({ source: 'flow-recorder-extension', type: 'RECAPTURE_STEP_RESULT', requestId, result }, location.origin);
    }
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'RECORDER_STATE') syncState();
  if (message?.type === 'RECORDER_NAVIGATION') setTimeout(recordNavigationIfNeeded, 0);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'PREPARE_FLOW_SCREENSHOT') {
    beginSensitiveMask();
    beginCaptureUi();
    recorder.host.getBoundingClientRect();
    requestAnimationFrame(() => requestAnimationFrame(() => sendResponse({ ok: true })));
    return true;
  }
  if (message?.type === 'FINISH_FLOW_SCREENSHOT') {
    endCaptureUi();
    endSensitiveMask();
    sendResponse({ ok: true });
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (['recording', 'paused', 'sessionId', 'title', 'startedAt', 'recordingTabId'].some((key) => changes[key])) syncState();
});

window.addEventListener('focus', () => {
  if (state.recording) refreshStepPreview();
  else refreshGuide();
});
window.addEventListener('resize', () => {
  keepRecorderInViewport();
  updateGuideHighlight();
});
window.addEventListener('scroll', () => {
  updateGuideHighlight();
  if (!state.recording || state.paused) return;
  const currentY = window.scrollY;
  const delta = currentY - lastRecordedScrollY;
  lastRecordedScrollY = currentY;
  if (Math.abs(delta) < 12) return;
  pendingScrollHint = delta > 0 ? 'down' : 'up';
}, true);

document.addEventListener('pointerdown', (event) => {
  if (isFromOurUi(event)) return;
  if (!state.recording || state.paused) return;
  const target = findTargetNode(event);
  if (!target) return;
  const occurredAt = Date.now();
  flushPendingInput(target, occurredAt - 1);
  const anchor = target.closest?.('a[href]');
  const shouldDelayNavigation = Boolean(anchor?.href && !anchor.hasAttribute('download') && !anchor.target && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey);
  if (shouldDelayNavigation) event.preventDefault();
  const capturePromise = captureEvent({
    type: 'click',
    occurredAt: new Date(occurredAt).toISOString(),
    url: location.href,
    locator: buildLocator(target),
    label: getLabel(target),
    x: event.clientX,
    y: event.clientY,
    scrollHint: takeScrollHint()
  }, { pulse: { x: event.clientX, y: event.clientY } });
  if (shouldDelayNavigation) {
    void capturePromise.finally(() => {
      if (document.visibilityState === 'visible') location.assign(anchor.href);
    });
  }
}, true);

document.addEventListener('click', (event) => {
  if (isFromOurUi(event)) return;
  if (event.isTrusted && activeGuide?.step?.action?.type === 'click' && isGuidedTarget(event.target, event)) {
    void advanceGuide();
  }
}, true);

document.addEventListener('input', (event) => {
  if (isFromOurUi(event)) return;
  if (event.isTrusted && activeGuide?.step?.action?.type === 'input' && isGuidedTarget(event.target, event)) {
    void advanceGuide();
  }
  if (state.recording && !state.paused && isEditableField(event.target)) dirtyFields.add(event.target);
}, true);

document.addEventListener('change', (event) => {
  if (isFromOurUi(event)) return;
  if (event.isTrusted && activeGuide?.step?.action?.type === 'input' && isGuidedTarget(event.target, event)) {
    void advanceGuide();
    return;
  }
  if (!state.recording || state.paused || isFromOurUi(event)) return;
  const target = findTargetNode(event);
  if (!target || !['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) return;
  if (skipNextChange.has(target)) {
    skipNextChange.delete(target);
    return;
  }
  captureInputEvent(target, Date.now());
}, true);

document.addEventListener('keydown', (event) => {
  if (event.isTrusted && event.key === 'F8' && !event.repeat && activeTargeting?.phase === 'ready') {
    event.preventDefault();
    event.stopImmediatePropagation();
    void armTargeting();
    return;
  }
  if (isFromOurUi(event)) return;
  if (event.isTrusted && event.key === 'Enter' && activeGuide?.step?.action?.type === 'enter' && isGuidedTarget(event.target, event)) {
    void advanceGuide();
    return;
  }
  if (event.isTrusted && activeGuide?.step?.action?.type === 'shortcut' && matchesShortcut(event, activeGuide.step.action.keys || activeGuide.step.keys)) {
    event.preventDefault();
    void advanceGuide();
    return;
  }
  if (event.key !== 'Enter' || !state.recording || state.paused || isFromOurUi(event)) return;
  const target = findTargetNode(event);
  if (!target) return;
  const occurredAt = Date.now();
  flushPendingInput(null, occurredAt - 1);
  captureEvent({
    type: 'enter',
    occurredAt: new Date(occurredAt).toISOString(),
    url: location.href,
    locator: buildLocator(target),
    label: getLabel(target),
    ...elementCenter(target),
    valuePolicy: 'none',
    scrollHint: takeScrollHint()
  });
}, true);

async function syncState() {
  const [stored, context] = await Promise.all([
    chrome.storage.local.get(['recording', 'paused', 'sessionId', 'title', 'startedAt']),
    sendRuntimeMessage({ type: 'getRecordingContext' })
  ]);
  const wasRecording = state.recording;
  browserTabId = context?.tabId || null;
  targetingClaimToken = context?.targetingClaimToken || targetingClaimToken;
  state = {
    recording: Boolean(stored.recording && context?.isRecordingTab),
    paused: Boolean(stored.paused),
    sessionId: stored.sessionId || null,
    title: stored.title || '',
    startedAt: Number(stored.startedAt || Date.now())
  };

  recorder.host.style.display = state.recording ? 'block' : 'none';
  recorder.pause.textContent = state.paused ? '▶' : '⏸';
  if (state.recording) {
    hideGuide();
    applySavedRecorderPosition();
    await refreshStepPreview();
    if (!wasRecording || lastNavigationKey !== `${state.sessionId}:${location.href}`) recordNavigationIfNeeded();
  } else {
    await refreshOverlays();
  }
}

function recordNavigationIfNeeded() {
  const key = `${state.sessionId}:${location.href}`;
  if (!state.recording || state.paused || lastNavigationKey === key) return;
  lastNavigationKey = key;
  captureEvent({ type: 'navigation', url: location.href, locator: {}, label: document.title, valuePolicy: 'none' });
}

async function captureEvent(payload, { pulse } = {}) {
  if (!state.recording || state.paused || !state.sessionId) return { ok: false, error: 'not_recording' };
  const eventId = crypto.randomUUID();
  const fullPayload = {
    ...payload,
    eventId,
    occurredAt: payload.occurredAt || new Date().toISOString(),
    elapsedMs: Math.max(0, Date.now() - state.startedAt),
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight,
      scrollX: window.scrollX,
      scrollY: window.scrollY
    },
    scrollHint: payload.scrollHint || ''
  };

  beginSensitiveMask();
  beginCaptureUi();
  let result;
  try {
    // Force the visibility and masking changes into layout before asking Chrome for the visible tab.
    recorder.host.getBoundingClientRect();
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    result = await sendRuntimeMessage({ type: 'captureAndSend', payload: fullPayload });
  } finally {
    endCaptureUi();
    endSensitiveMask();
  }

  if (result?.ok) {
    if (pulse) showPulse(pulse.x, pulse.y);
    await refreshStepPreview();
    if (result.warning && !result.hasScreenshot) setRecorderStatus('步骤已记录，但本次截图失败');
  } else if (result?.error && result.error !== 'not_recording') {
    setRecorderStatus(`录制失败：${result.error}`);
  }
  return result || { ok: false, error: 'empty_capture_result' };
}

function takeScrollHint() {
  const hint = pendingScrollHint;
  pendingScrollHint = '';
  return hint;
}

async function refreshStepPreview() {
  if (!state.sessionId) return;
  const result = await apiRequest(`/api/session/${encodeURIComponent(state.sessionId)}`);
  if (!result.ok) {
    if (result.error === 'session_not_found') {
      state.recording = false;
      await chrome.storage.local.set({ recording: false, paused: false, sessionId: null, title: '', startedAt: 0, recordingTabId: null });
      recorder.host.style.display = 'none';
      return;
    }
    setRecorderStatus(`无法读取步骤：${result.error}`);
    return;
  }
  const steps = result.data.session.steps || [];
  recorder.list.replaceChildren();
  steps.slice(-10).forEach((step, index) => {
    const row = document.createElement('div');
    row.className = 'step-row';
    row.textContent = `${steps.length - Math.min(10, steps.length) + index + 1}. ${step.text || '操作'}`;
    recorder.list.appendChild(row);
  });
  if (!steps.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    empty.textContent = '暂无步骤';
    recorder.list.appendChild(empty);
  }
  recorder.title.textContent = `${state.title || '录制中'}（${steps.length}步）`;
}

async function togglePause() {
  if (!state.sessionId) return;
  const nextPaused = !state.paused;
  const result = await apiRequest(`/api/session/${encodeURIComponent(state.sessionId)}/state`, {
    method: 'POST',
    body: { status: nextPaused ? 'paused' : 'recording' }
  });
  if (!result.ok) return setRecorderStatus(`操作失败：${result.error}`);
  await chrome.storage.local.set({ paused: nextPaused, recording: true });
}

async function deleteSession() {
  if (!state.sessionId || !confirm('确定删除这次录制吗？')) return;
  const result = await apiRequest(`/api/session/${encodeURIComponent(state.sessionId)}`, { method: 'DELETE' });
  if (!result.ok) return setRecorderStatus(`删除失败：${result.error}`);
  await chrome.storage.local.set({ recording: false, paused: false, sessionId: null, title: '', startedAt: 0, recordingTabId: null });
}

async function saveSession() {
  if (!state.sessionId) return;
  const result = await apiRequest(`/api/session/${encodeURIComponent(state.sessionId)}/state`, {
    method: 'POST',
    body: { status: 'stopped' }
  });
  if (!result.ok) return setRecorderStatus(`保存失败：${result.error}`);
  const sessionId = state.sessionId;
  const opened = await sendRuntimeMessage({ type: 'openEditor', sessionId });
  if (!opened?.ok) return setRecorderStatus(`已保存，但无法打开编辑页：${opened?.error || '未知错误'}`);
  await chrome.storage.local.set({ recording: false, paused: false, recordingTabId: null });
}

function startGuidePolling() {
  clearInterval(guidePoll);
  guidePoll = setInterval(() => {
    if (!state.recording) void refreshOverlays();
  }, 1500);
}

async function refreshOverlays() {
  if (await refreshTargeting()) return;
  await refreshGuide();
}

async function refreshTargeting() {
  if (!browserTabId || document.visibilityState !== 'visible') return false;
  if (pendingTargetSelection && ['selected', 'saving'].includes(activeTargeting?.phase)) return true;
  const clientId = `tab:${browserTabId}`;
  const claimToken = targetingClaimToken;
  const requestVersion = targetingStateVersion;
  const result = await apiRequest(`/api/targeting?clientId=${encodeURIComponent(clientId)}&claimToken=${encodeURIComponent(claimToken)}&url=${encodeURIComponent(location.href)}`);
  if (requestVersion !== targetingStateVersion) return Boolean(activeTargeting);
  if (!result.ok || !result.data.targeting) {
    hideTargeting();
    return false;
  }
  activeTargeting = result.data.targeting;
  if (targetingClaimToken) {
    targetingClaimToken = '';
    void sendRuntimeMessage({ type: 'clearTargetingClaim' });
  }
  hideGuide();
  targeting.host.style.display = 'block';
  targeting.title.textContent = activeTargeting.mode === 'element' ? '选择正确元素' : '拖拽框选区域';
  targeting.text.textContent = activeTargeting.stepText || '修正当前步骤的引导位置';
  const armed = activeTargeting.phase === 'armed';
  targeting.activate.hidden = armed;
  targeting.activate.textContent = activeTargeting.mode === 'element' ? '开始选择元素' : '开始框选区域';
  targeting.tip.textContent = armed
    ? activeTargeting.mode === 'element'
      ? '标注已开启：移动鼠标预览，点击元素后保存'
      : '标注已开启：按住并拖动，松开后保存'
    : '你可以先正常操作页面。弹窗容易失焦时请按 F8；普通页面也可点击上方按钮。';
  return true;
}

function hideTargeting() {
  targetingStateVersion += 1;
  activeTargeting = null;
  regionDragStart = null;
  targetingArmPromise = null;
  pendingTargetSelection = null;
  targeting.host.style.display = 'none';
  targeting.selection.style.display = 'none';
}

async function cancelTargeting() {
  await apiRequest('/api/targeting/cancel', {
    method: 'POST', body: { clientId: `tab:${browserTabId}` }
  });
  hideTargeting();
}

async function armTargeting() {
  if (!activeTargeting || activeTargeting.phase !== 'ready') return;
  targetingStateVersion += 1;
  const armVersion = targetingStateVersion;
  const targetingBeingArmed = activeTargeting;
  pendingTargetSelection = null;
  activeTargeting.phase = 'arming';
  targeting.activate.hidden = true;
  targeting.tip.textContent = '正在开启标注…';
  targetingArmPromise = apiRequest('/api/targeting/arm', {
    method: 'POST', body: { clientId: `tab:${browserTabId}` }
  });
  const result = await targetingArmPromise;
  if (targetingStateVersion !== armVersion || activeTargeting !== targetingBeingArmed) return;
  targetingArmPromise = null;
  if (!result.ok) {
    targetingStateVersion += 1;
    activeTargeting.phase = 'ready';
    targeting.activate.hidden = false;
    targeting.tip.textContent = `无法开始标注：${result.error}`;
    return;
  }
  activeTargeting.phase = 'armed';
  targeting.activate.hidden = true;
  targeting.tip.textContent = activeTargeting.mode === 'element'
    ? '标注已开启：请点击要高亮的元素'
    : '标注已开启：请拖拽框出要高亮的区域';
}

function handleTargetingPrimaryAction() {
  if (activeTargeting?.phase === 'selected' && pendingTargetSelection) {
    void completeTargeting(pendingTargetSelection);
    return;
  }
  void armTargeting();
}

function isTargetingArmed(mode) {
  return ['arming', 'armed'].includes(activeTargeting?.phase) && (!mode || activeTargeting.mode === mode);
}

document.addEventListener('pointermove', (event) => {
  if (!isTargetingArmed() || isFromOurUi(event)) return;
  if (activeTargeting.mode === 'element') {
    const target = findTargetingNode(event);
    if (target) showTargetingRect(target.getBoundingClientRect());
  } else if (regionDragStart) {
    showTargetingRect(rectFromPoints(regionDragStart, { x: event.clientX, y: event.clientY }));
  }
}, true);

document.addEventListener('pointerdown', (event) => {
  if (!isTargetingArmed() || isFromOurUi(event)) return;
  if (activeTargeting.mode === 'element') {
    return;
  }
  event.preventDefault();
  event.stopImmediatePropagation();
  regionDragStart = { x: event.clientX, y: event.clientY };
  showTargetingRect({ left: event.clientX, top: event.clientY, width: 1, height: 1 });
}, true);

document.addEventListener('pointerup', (event) => {
  if (!isTargetingArmed() || isFromOurUi(event)) return;
  if (activeTargeting.mode === 'element') {
    return;
  }
  if (!regionDragStart) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  const rect = rectFromPoints(regionDragStart, { x: event.clientX, y: event.clientY });
  regionDragStart = null;
  if (rect.width < 12 || rect.height < 12) {
    targeting.tip.textContent = '区域太小，请重新拖拽';
    targeting.selection.style.display = 'none';
    return;
  }
  void completeTargeting({ region: {
    xRatio: rect.left / window.innerWidth,
    yRatio: rect.top / window.innerHeight,
    widthRatio: rect.width / window.innerWidth,
    heightRatio: rect.height / window.innerHeight
  } });
}, true);

document.addEventListener('click', (event) => {
  if (!isTargetingArmed('element') || isFromOurUi(event)) return;
  const target = findTargetingNode(event);
  if (!target) {
    targeting.tip.textContent = '没有识别到页面元素，请点击内容区域重试';
    return;
  }
  event.preventDefault();
  event.stopImmediatePropagation();
  const label = getLabel(target) || target.tagName.toLowerCase();
  pendingTargetSelection = { locator: buildLocator(target), label };
  activeTargeting.phase = 'selected';
  showTargetingRect(target.getBoundingClientRect());
  targeting.activate.hidden = false;
  targeting.activate.disabled = false;
  targeting.activate.textContent = '保存此元素';
  targeting.tip.textContent = `已选择“${label.slice(0, 48)}”，确认无误后点击保存`;
}, true);

async function completeTargeting(payload) {
  if (activeTargeting?.phase === 'arming' && targetingArmPromise) await targetingArmPromise;
  if (!['armed', 'selected'].includes(activeTargeting?.phase)) return;
  activeTargeting.phase = 'saving';
  targeting.activate.disabled = true;
  targeting.tip.textContent = '正在保存…';
  beginCaptureUi();
  let result;
  try {
    targeting.host.getBoundingClientRect();
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    result = await sendRuntimeMessage({
      type: 'completeTargeting',
      payload: { clientId: `tab:${browserTabId}`, ...payload }
    });
  } finally {
    endCaptureUi();
  }
  if (result.ok) {
    targeting.activate.hidden = true;
    targeting.tip.textContent = '保存成功，正在返回编辑页面…';
    const opened = await sendRuntimeMessage({
      type: 'openEditor',
      sessionId: activeTargeting.sessionId,
      stepId: activeTargeting.stepId
    });
    if (!opened?.ok) {
      activeTargeting.phase = 'selected';
      targeting.activate.disabled = false;
      targeting.activate.hidden = false;
      targeting.activate.textContent = '返回编辑页面';
      targeting.tip.textContent = `元素已保存，但返回编辑页面失败：${opened?.error || '未知错误'}`;
      return;
    }
    window.setTimeout(hideTargeting, 900);
  } else {
    activeTargeting.phase = 'selected';
    targeting.activate.disabled = false;
    targeting.activate.hidden = false;
    targeting.activate.textContent = '重新保存';
    targeting.tip.textContent = `保存失败：${result.error}`;
  }
}

function showTargetingRect(rect) {
  targeting.selection.style.display = 'block';
  targeting.selection.style.left = `${rect.left}px`;
  targeting.selection.style.top = `${rect.top}px`;
  targeting.selection.style.width = `${rect.width}px`;
  targeting.selection.style.height = `${rect.height}px`;
}

function rectFromPoints(start, end) {
  return {
    left: Math.max(0, Math.min(start.x, end.x)),
    top: Math.max(0, Math.min(start.y, end.y)),
    width: Math.min(window.innerWidth, Math.max(start.x, end.x)) - Math.max(0, Math.min(start.x, end.x)),
    height: Math.min(window.innerHeight, Math.max(start.y, end.y)) - Math.max(0, Math.min(start.y, end.y))
  };
}

async function refreshGuide() {
  if (!browserTabId || document.visibilityState !== 'visible') {
    suspendGuideDisplay();
    return;
  }
  const clientId = `tab:${browserTabId}`;
  const result = await apiRequest(`/api/guide?clientId=${encodeURIComponent(clientId)}&url=${encodeURIComponent(location.href)}`);
  if (!result.ok || !result.data.guide) {
    hideGuide();
    return;
  }
  activeGuide = result.data.guide;
  renderGuide(activeGuide);
}

function renderGuide(current) {
  const step = current.step;
  guide.host.style.display = 'block';
  guide.counter.textContent = `${current.stepIndex + 1} / ${current.stepCount}`;
  guide.text.textContent = step.text || '请完成当前步骤';
  const scrollDirection = step.scrollHint === 'up' || /^返回页面上方|^向上/.test(step.text || '') ? 'up' : step.scrollHint === 'down' || /^向下/.test(step.text || '') ? 'down' : '';
  guide.scrollHint.style.display = scrollDirection ? 'flex' : 'none';
  guide.scrollHint.className = `scroll-hint ${scrollDirection}`;
  guide.scrollArrow.textContent = scrollDirection === 'up' ? '↑' : '↓';
  guide.scrollLabel.textContent = scrollDirection === 'up' ? '返回页面上方' : '向下浏览页面';
  guide.open.hidden = true;

  if (!isSamePage(step.url, location.href)) {
    guidedElement = null;
    guidedRegion = null;
    guide.host.style.display = 'none';
    guide.highlight.style.display = 'none';
    guide.cursor.style.display = 'none';
    return;
  }

  if (step.action?.type === 'navigation') {
    guidedElement = null;
    guidedRegion = null;
    guide.status.textContent = '页面已打开，可继续下一步';
    updateGuideHighlight();
    return;
  }

  const preferRegion = step.targetMode === 'region' && step.manualRegion;
  guidedElement = preferRegion ? null : findByLocator(step.action?.locator || {});
  guidedRegion = preferRegion || !guidedElement ? step.manualRegion : null;
  guide.status.textContent = guidedElement
    ? '已定位目标，点击高亮区域后自动进入下一步'
    : preferRegion
      ? '正在使用框选区域，点击区域后自动进入下一步'
      : guidedRegion
      ? '原元素未找到，点击框选区域后自动进入下一步'
      : '未找到原元素，请手动完成后点击“下一步”';
  if (step.action?.type === 'shortcut') {
    guidedElement = null;
    guidedRegion = null;
    guide.status.textContent = '请按下文案中的快捷键，完成后会自动进入下一步';
    guide.highlight.style.display = 'none';
    guide.cursor.style.display = 'none';
    return;
  }
  if (guidedElement) guidedElement.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
  updateGuideHighlight();
}

function matchesShortcut(event, keys = []) {
  const normalized = new Set(keys.map((key) => String(key).toUpperCase()));
  const pressed = new Set();
  if (event.metaKey) pressed.add('⌘');
  if (event.ctrlKey) pressed.add('CTRL');
  if (event.altKey) pressed.add('ALT');
  if (event.shiftKey) pressed.add('SHIFT');
  const key = event.key.length === 1 ? event.key.toUpperCase() : event.key.replace('Arrow', '').toUpperCase();
  if (!['META', 'CONTROL', 'ALT', 'SHIFT'].includes(event.key.toUpperCase())) pressed.add(key === ' ' ? 'SPACE' : key);
  return normalized.size > 0 && normalized.size === pressed.size && [...normalized].every((item) => pressed.has(item === '⌘' ? '⌘' : item));
}

async function advanceGuide() {
  if (guideAdvancePending) return;
  guideAdvancePending = true;
  try {
    const result = await apiRequest('/api/guide/advance', {
      method: 'POST',
      body: { clientId: browserTabId ? `tab:${browserTabId}` : '' }
    });
    if (!result.ok) return;
    if (result.data.completed) hideGuide();
    else {
      activeGuide = result.data.guide;
      renderGuide(activeGuide);
    }
  } finally {
    guideAdvancePending = false;
  }
}

async function stopGuide() {
  await apiRequest('/api/guide/stop', { method: 'POST' });
  hideGuide();
}

function hideGuide() {
  activeGuide = null;
  guidedElement = null;
  guidedRegion = null;
  guide.host.style.display = 'none';
  guide.highlight.style.display = 'none';
  guide.cursor.style.display = 'none';
}

function suspendGuideDisplay() {
  guidedElement = null;
  guidedRegion = null;
  guide.host.style.display = 'none';
  guide.highlight.style.display = 'none';
  guide.cursor.style.display = 'none';
}

function updateGuideHighlight() {
  if (!activeGuide) {
    guide.highlight.style.display = 'none';
    guide.cursor.style.display = 'none';
    return;
  }
  const rect = guidedElement?.isConnected
    ? guidedElement.getBoundingClientRect()
    : regionToRect(guidedRegion);
  if (!rect) {
    guide.highlight.style.display = 'none';
    guide.cursor.style.display = 'none';
    return;
  }
  if (rect.width <= 0 || rect.height <= 0) {
    guide.highlight.style.display = 'none';
    guide.cursor.style.display = 'none';
    return;
  }
  guide.highlight.style.display = 'block';
  guide.highlight.style.left = `${rect.left - 6}px`;
  guide.highlight.style.top = `${rect.top - 6}px`;
  guide.highlight.style.width = `${rect.width + 12}px`;
  guide.highlight.style.height = `${rect.height + 12}px`;
  const cursorX = Math.min(window.innerWidth - 20, Math.max(12, rect.left + rect.width * .58));
  const cursorY = Math.min(window.innerHeight - 24, Math.max(12, rect.top + rect.height * .58));
  guide.cursor.className = `cursor ${activeGuide.step.action?.type || 'click'}`;
  guide.cursor.style.display = 'block';
  guide.cursor.style.left = `${cursorX}px`;
  guide.cursor.style.top = `${cursorY}px`;
}

function regionToRect(region) {
  if (!region) return null;
  return {
    left: region.xRatio * window.innerWidth,
    top: region.yRatio * window.innerHeight,
    width: region.widthRatio * window.innerWidth,
    height: region.heightRatio * window.innerHeight
  };
}

function buildLocator(element) {
  const tag = element.tagName.toLowerCase();
  const testId = element.getAttribute('data-testid') || element.getAttribute('data-test-id') || '';
  const id = element.id || '';
  const ariaLabel = element.getAttribute('aria-label') || '';
  const name = element.getAttribute('name') || '';
  return {
    testId,
    id,
    ariaLabel,
    name,
    css: buildUniqueCss(element),
    text: getLabel(element),
    tag
  };
}

function buildUniqueCss(element) {
  if (element.id) return `#${CSS.escape(element.id)}`;
  for (const attribute of ['data-testid', 'data-test-id']) {
    const value = element.getAttribute(attribute);
    if (value) return `[${attribute}="${CSS.escape(value)}"]`;
  }
  const parts = [];
  let current = element;
  while (current && current.nodeType === Node.ELEMENT_NODE && current !== document.documentElement && parts.length < 5) {
    let part = current.tagName.toLowerCase();
    const siblings = current.parentElement
      ? [...current.parentElement.children].filter((child) => child.tagName === current.tagName)
      : [];
    if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
    parts.unshift(part);
    const candidate = parts.join(' > ');
    try {
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    } catch {}
    current = current.parentElement;
  }
  return parts.join(' > ');
}

function findByLocator(locator) {
  const candidates = [];
  if (locator.testId) {
    candidates.push(`[data-testid="${CSS.escape(locator.testId)}"]`, `[data-test-id="${CSS.escape(locator.testId)}"]`);
  }
  if (locator.id) candidates.push(`#${CSS.escape(locator.id)}`);
  if (locator.ariaLabel) candidates.push(`[aria-label="${CSS.escape(locator.ariaLabel)}"]`);
  if (locator.name) candidates.push(`[name="${CSS.escape(locator.name)}"]`);
  if (locator.css) candidates.push(locator.css);
  for (const candidate of candidates) {
    try {
      const matches = [...document.querySelectorAll(candidate)]
        .filter(isVisible)
        .filter((element) => matchesLocatorEvidence(element, locator));
      if (matches.length === 1) return matches[0];
    } catch {}
  }
  return null;
}

function findTargetNode(event) {
  const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
  for (const node of path) {
    if (!(node instanceof Element) || isOurHost(node)) continue;
    const interactive = node.closest?.('button,a[href],input,textarea,select,summary,label,[role="button"],[role="link"],[role="menuitem"],[role="tab"],[role="checkbox"],[role="radio"],[role="switch"],[tabindex]:not([tabindex="-1"]),[onclick]');
    if (interactive) return interactive;
  }
  return null;
}

function findTargetingNode(event) {
  const interactive = findTargetNode(event);
  if (interactive) return interactive;
  const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
  for (const node of path) {
    if (!(node instanceof Element) || isOurHost(node)) continue;
    if (node === document.documentElement || node === document.body) continue;
    return node;
  }
  return null;
}

function matchesLocatorEvidence(element, locator) {
  if (locator.tag && element.tagName.toLowerCase() !== locator.tag.toLowerCase()) return false;
  if (locator.id && element.id !== locator.id) return false;
  if (locator.testId) {
    const currentTestId = element.getAttribute('data-testid') || element.getAttribute('data-test-id') || '';
    if (currentTestId !== locator.testId) return false;
  }
  if (locator.ariaLabel && element.getAttribute('aria-label') !== locator.ariaLabel) return false;
  if (locator.name && element.getAttribute('name') !== locator.name) return false;
  if (locator.text && getLabel(element) !== locator.text) return false;
  return true;
}

function isGuidedTarget(target, event) {
  if (guidedElement && target instanceof Node && (target === guidedElement || guidedElement.contains(target))) return true;
  if (!guidedRegion || !event || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return false;
  const rect = regionToRect(guidedRegion);
  return Boolean(rect && event.clientX >= rect.left && event.clientX <= rect.left + rect.width && event.clientY >= rect.top && event.clientY <= rect.top + rect.height);
}

function getLabel(element) {
  if (!element) return '';
  if (element.tagName === 'SELECT') {
    return String(element.labels?.[0]?.innerText || element.getAttribute('aria-label') || element.getAttribute('title') || element.getAttribute('name') || '').trim().slice(0, 160);
  }
  const associated = element.labels?.[0]?.innerText || '';
  const text = associated || element.getAttribute('aria-label') || element.getAttribute('title') || element.getAttribute('placeholder') || element.innerText || element.textContent || '';
  return String(text).replace(/\s+/g, ' ').trim().slice(0, 160);
}

function isSensitiveField(element) {
  if (element.tagName !== 'INPUT' && element.tagName !== 'TEXTAREA') return false;
  if (element.type === 'password') return true;
  if (element.hasAttribute('data-sensitive') || element.hasAttribute('data-flow-recorder-sensitive')) return true;
  const autocomplete = String(element.getAttribute('autocomplete') || '').toLowerCase();
  if (autocomplete.split(/\s+/).some((token) => SENSITIVE_AUTOCOMPLETE.has(token))) return true;
  const identity = `${element.id || ''} ${element.getAttribute('name') || ''} ${getLabel(element)}`;
  return /(password|passwd|secret|token|otp|one.?time|verification.?code|auth.?code|cvv|cvc|card.?number|密码|口令|验证码|动态码|令牌|密钥|银行卡|卡号|安全码)/i.test(identity);
}

function isEditableField(element) {
  return element instanceof Element && ['INPUT', 'TEXTAREA', 'SELECT'].includes(element.tagName);
}

function flushPendingInput(nextTarget, occurredAt) {
  const active = document.activeElement;
  if (!isEditableField(active) || active === nextTarget || !dirtyFields.has(active)) return;
  dirtyFields.delete(active);
  skipNextChange.add(active);
  setTimeout(() => skipNextChange.delete(active), 0);
  captureInputEvent(active, occurredAt);
}

function captureInputEvent(target, occurredAt) {
  dirtyFields.delete(target);
  const sensitive = isSensitiveField(target);
  captureEvent({
    type: 'input',
    occurredAt: new Date(occurredAt).toISOString(),
    url: location.href,
    locator: buildLocator(target),
    label: getLabel(target),
    ...elementCenter(target),
    value: sensitive ? '' : String(target.value || '').slice(0, 500),
    valuePolicy: sensitive ? 'redacted' : 'literal',
    sensitive,
    scrollHint: takeScrollHint()
  });
}

function elementCenter(element) {
  const rect = element.getBoundingClientRect();
  return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
}

function beginSensitiveMask() {
  sensitiveMaskLocks += 1;
  if (sensitiveMaskLocks > 1) return;
  const fieldRestorers = [...document.querySelectorAll('input,textarea')]
    .filter(isSensitiveField)
    .map((element) => {
      const properties = ['color', '-webkit-text-fill-color', 'text-shadow', 'caret-color'];
      const previous = properties.map((property) => ({
        property,
        value: element.style.getPropertyValue(property),
        priority: element.style.getPropertyPriority(property)
      }));
      element.style.setProperty('color', 'transparent', 'important');
      element.style.setProperty('-webkit-text-fill-color', 'transparent', 'important');
      element.style.setProperty('text-shadow', 'none', 'important');
      element.style.setProperty('caret-color', 'transparent', 'important');
      return () => previous.forEach(({ property, value, priority }) => {
        if (value) element.style.setProperty(property, value, priority);
        else element.style.removeProperty(property);
      });
    });
  const frameRestorers = [...document.querySelectorAll('iframe')].map((frame) => {
    const visibility = frame.style.getPropertyValue('visibility');
    const priority = frame.style.getPropertyPriority('visibility');
    frame.style.setProperty('visibility', 'hidden', 'important');
    return () => {
      if (visibility) frame.style.setProperty('visibility', visibility, priority);
      else frame.style.removeProperty('visibility');
    };
  });
  restoreSensitiveMask = () => [...fieldRestorers, ...frameRestorers].forEach((restore) => restore());
}

function endSensitiveMask() {
  sensitiveMaskLocks = Math.max(0, sensitiveMaskLocks - 1);
  if (sensitiveMaskLocks > 0) return;
  restoreSensitiveMask?.();
  restoreSensitiveMask = null;
}

function isSamePage(expected, actual) {
  if (!expected) return true;
  try {
    const a = new URL(expected);
    const b = new URL(actual);
    return a.origin === b.origin && a.pathname === b.pathname && a.search === b.search && a.hash === b.hash;
  } catch {
    return false;
  }
}

function isVisible(element) {
  if (!(element instanceof Element)) return false;
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
}

function isFromOurUi(event) {
  return event.composedPath().some(isOurHost);
}

function isOurHost(node) {
  return node === recorder.host || node === guide.host || node === targeting.host || node === pulseLayer.host;
}

function beginCaptureUi() {
  captureUiLocks += 1;
  if (captureUiLocks > 1) return;
  captureUiStyles = [recorder.host, guide.host, targeting.host, pulseLayer.host].map((host) => ({
    host,
    display: host.style.display,
    visibility: host.style.visibility
  }));
  recorder.host.style.visibility = 'hidden';
  guide.host.style.visibility = 'hidden';
  targeting.host.style.visibility = 'hidden';
  pulseLayer.host.style.visibility = 'hidden';
  captureUiStyles.forEach(({ host }) => {
    host.style.display = 'none';
  });
}

function endCaptureUi() {
  captureUiLocks = Math.max(0, captureUiLocks - 1);
  if (captureUiLocks > 0) return;
  captureUiStyles?.forEach(({ host, display, visibility }) => {
    host.style.display = display;
    host.style.visibility = visibility;
  });
  captureUiStyles = null;
}

function showPulse(x, y) {
  const dot = document.createElement('div');
  dot.className = 'pulse';
  dot.style.left = `${x}px`;
  dot.style.top = `${y}px`;
  pulseLayer.root.appendChild(dot);
  setTimeout(() => dot.remove(), 650);
}

function setRecorderStatus(message) {
  recorder.title.textContent = message;
}

function apiRequest(path, { method = 'GET', body } = {}) {
  return sendRuntimeMessage({ type: 'apiRequest', request: { path, method, body } });
}

function sendRuntimeMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(response || { ok: false, error: 'empty_response' });
    });
  });
}

function bindRecorderActions() {
  recorder.pause.addEventListener('click', togglePause);
  recorder.remove.addEventListener('click', deleteSession);
  recorder.save.addEventListener('click', saveSession);
}

function bindGuideActions() {
  guide.next.addEventListener('click', advanceGuide);
  guide.stop.addEventListener('click', stopGuide);
}

function setupRecorderDrag() {
  let dragging = false;
  let offsetX = 0;
  let offsetY = 0;
  recorder.header.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button')) return;
    dragging = true;
    const rect = recorder.host.getBoundingClientRect();
    offsetX = event.clientX - rect.left;
    offsetY = event.clientY - rect.top;
    recorder.header.setPointerCapture(event.pointerId);
  });
  recorder.header.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    applyRecorderPosition(event.clientX - offsetX, event.clientY - offsetY);
  });
  const stop = (event) => {
    if (!dragging) return;
    dragging = false;
    try { recorder.header.releasePointerCapture(event.pointerId); } catch {}
  };
  recorder.header.addEventListener('pointerup', stop);
  recorder.header.addEventListener('pointercancel', stop);
}

function applySavedRecorderPosition() {
  try {
    const saved = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
    if (Number.isFinite(saved?.x) && Number.isFinite(saved?.y)) applyRecorderPosition(saved.x, saved.y);
    else applyRecorderPosition(window.innerWidth - 376, 70);
  } catch {
    applyRecorderPosition(window.innerWidth - 376, 70);
  }
}

function applyRecorderPosition(x, y) {
  const maxX = Math.max(8, window.innerWidth - recorder.host.offsetWidth - 8);
  const maxY = Math.max(8, window.innerHeight - recorder.host.offsetHeight - 8);
  const safeX = Math.max(8, Math.min(maxX, x));
  const safeY = Math.max(8, Math.min(maxY, y));
  recorder.host.style.left = `${safeX}px`;
  recorder.host.style.top = `${safeY}px`;
  try { localStorage.setItem(POS_KEY, JSON.stringify({ x: safeX, y: safeY })); } catch {}
}

function keepRecorderInViewport() {
  const rect = recorder.host.getBoundingClientRect();
  applyRecorderPosition(rect.left, rect.top);
}

function createRecorderOverlay() {
  const host = document.createElement('div');
  host.id = 'flowRecorderHost';
  Object.assign(host.style, {
    position: 'fixed', left: '8px', top: '70px', width: '360px', zIndex: '2147483646', display: 'none'
  });
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      *{box-sizing:border-box} .card{max-height:70vh;overflow:hidden;background:rgba(255,255,255,.98);border:1px solid #ececf5;border-radius:14px;box-shadow:0 10px 30px rgba(16,24,40,.2);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#222}
      .header{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;border-bottom:1px solid #f0f1f6;cursor:move;background:#fbfbff;user-select:none}.title{font-weight:700;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.actions{display:flex;gap:6px;align-items:center}.actions button{border:0;border-radius:999px;width:30px;height:30px;cursor:pointer;font-size:14px}.pause{background:#eef0ff}.remove{background:#ffe8e8}.save{width:34px!important;height:34px!important;background:#5b44ff;color:white}.list{font-size:12px;color:#444;max-height:calc(70vh - 54px);overflow:auto;padding:8px 12px}.step-row{padding:7px 0;border-bottom:1px solid #f1f2f7;line-height:1.45}.empty{padding:12px 0;color:#777}
    </style>
    <div class="card"><div class="header"><div class="title">录制中</div><div class="actions"><button class="pause" title="暂停">⏸</button><button class="remove" title="删除">🗑</button><button class="save" title="保存">✓</button></div></div><div class="list"></div></div>`;
  document.documentElement.appendChild(host);
  return {
    host,
    root,
    header: root.querySelector('.header'),
    title: root.querySelector('.title'),
    list: root.querySelector('.list'),
    pause: root.querySelector('.pause'),
    remove: root.querySelector('.remove'),
    save: root.querySelector('.save')
  };
}

function createGuideOverlay() {
  const host = document.createElement('div');
  host.id = 'flowGuideHost';
  Object.assign(host.style, {
    position: 'fixed', inset: '0', zIndex: '2147483647', display: 'none', pointerEvents: 'none'
  });
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      *{box-sizing:border-box}.highlight{display:none;position:fixed;border:3px solid #6d4aff;border-radius:10px;box-shadow:0 0 0 9999px rgba(18,18,26,.22),0 0 0 6px rgba(109,74,255,.2);pointer-events:none;transition:all .15s ease}.cursor{display:none;position:fixed;width:28px;height:34px;pointer-events:none;transform:translate(-4px,-3px);transition:left .48s cubic-bezier(.2,.8,.2,1),top .48s cubic-bezier(.2,.8,.2,1);filter:drop-shadow(0 3px 4px rgba(0,0,0,.25))}.cursor svg{display:block;width:28px;height:34px}.cursor-ripple{position:absolute;left:2px;top:2px;width:20px;height:20px;border:3px solid #7b61ff;border-radius:50%;opacity:0}.cursor.click .cursor-ripple{animation:guide-click 1.25s ease-out infinite}@keyframes guide-click{0%,35%{opacity:0;transform:scale(.35)}45%{opacity:.9}100%{opacity:0;transform:scale(1.8)}}.panel{position:fixed;right:20px;bottom:20px;width:340px;padding:16px;background:white;border-radius:14px;box-shadow:0 12px 36px rgba(0,0,0,.24);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#1f2937;pointer-events:auto}.top{display:flex;justify-content:space-between;font-size:12px;color:#6b7280}.text{font-size:15px;font-weight:650;line-height:1.5;margin:10px 0}.scroll-hint{display:none;align-items:center;gap:8px;margin:10px 0;padding:8px 10px;border:1px solid #d9d0ff;border-radius:9px;background:#f5f2ff;color:#5b44ff;font-size:12px;font-weight:700}.scroll-arrow{display:grid;place-items:center;width:22px;height:22px;border-radius:7px;background:#6d4aff;color:#fff;font-size:18px;line-height:1;animation:scroll-bounce 1.1s ease-in-out infinite}.scroll-hint.up{border-color:#c8e8ff;background:#eef9ff;color:#0875a4}.scroll-hint.up .scroll-arrow{background:#13a8d4}@keyframes scroll-bounce{0%,100%{transform:translateY(-2px)}50%{transform:translateY(3px)}}.status{font-size:12px;color:#6b7280;line-height:1.4}.actions{display:flex;gap:8px;margin-top:12px}.actions button{border:0;border-radius:9px;padding:8px 12px;cursor:pointer}.next,.open{background:#5b44ff;color:#fff}.stop{background:#f1f3f7;color:#374151}@media(prefers-reduced-motion:reduce){.cursor{transition:none}.scroll-arrow{animation:none}.cursor.click .cursor-ripple{animation:none}}
    </style>
    <div class="highlight"></div><div class="cursor" aria-hidden="true"><span class="cursor-ripple"></span><svg viewBox="0 0 28 34"><circle cx="14" cy="17" r="13" fill="#7b61ff" fill-opacity=".22" stroke="white" stroke-width="2"/><circle cx="14" cy="17" r="7" fill="none" stroke="#5b44ff" stroke-width="2.5"/><circle cx="14" cy="17" r="2.5" fill="#5b44ff" stroke="white" stroke-width="1"/></svg></div><div class="panel"><div class="top"><span>引导回放</span><span class="counter"></span></div><div class="text"></div><div class="scroll-hint"><span class="scroll-arrow">↓</span><span class="scroll-label">向下浏览页面</span></div><div class="status"></div><div class="actions"><button class="open" hidden>打开目标页面</button><button class="next">下一步</button><button class="stop">退出</button></div></div>`;
  document.documentElement.appendChild(host);
  return {
    host,
    root,
    highlight: root.querySelector('.highlight'),
    cursor: root.querySelector('.cursor'),
    counter: root.querySelector('.counter'),
    text: root.querySelector('.text'),
    scrollHint: root.querySelector('.scroll-hint'),
    scrollArrow: root.querySelector('.scroll-arrow'),
    scrollLabel: root.querySelector('.scroll-label'),
    status: root.querySelector('.status'),
    open: root.querySelector('.open'),
    next: root.querySelector('.next'),
    stop: root.querySelector('.stop')
  };
}

function createTargetingOverlay() {
  const host = document.createElement('div');
  host.id = 'flowTargetingHost';
  Object.assign(host.style, {
    position: 'fixed', inset: '0', zIndex: '2147483647', display: 'none', pointerEvents: 'none'
  });
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      *{box-sizing:border-box}.selection{display:none;position:fixed;border:3px solid #ff7a00;border-radius:8px;background:rgba(255,122,0,.08);box-shadow:0 0 0 3px rgba(255,122,0,.2);pointer-events:none}.panel{position:fixed;right:20px;top:20px;width:340px;padding:15px;background:#fff;border-radius:14px;box-shadow:0 12px 36px rgba(0,0,0,.24);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#1f2937;pointer-events:auto}.eyebrow{font-size:12px;font-weight:750;color:#ff6b00}.title{font-size:16px;font-weight:750;margin-top:5px}.text{font-size:13px;line-height:1.45;margin-top:8px}.tip{font-size:12px;color:#6b7280;margin-top:5px}.actions{display:flex;gap:8px;margin-top:12px}.actions button{border:0;border-radius:9px;padding:8px 12px;cursor:pointer}.activate{background:#ff6b00;color:#fff;font-weight:700}.cancel{background:#f1f3f7;color:#374151}
    </style>
    <div class="selection"></div><div class="panel"><div class="eyebrow">修正引导目标</div><div class="title"></div><div class="text"></div><div class="tip"></div><div class="actions"><button class="activate"></button><button class="cancel">取消</button></div></div>`;
  document.documentElement.appendChild(host);
  return {
    host,
    selection: root.querySelector('.selection'),
    title: root.querySelector('.title'),
    text: root.querySelector('.text'),
    tip: root.querySelector('.tip'),
    activate: root.querySelector('.activate'),
    cancel: root.querySelector('.cancel')
  };
}

function createPulseLayer() {
  const host = document.createElement('div');
  Object.assign(host.style, { position: 'fixed', inset: '0', zIndex: '2147483647', pointerEvents: 'none' });
  const root = host.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  style.textContent = '.pulse{position:fixed;width:18px;height:18px;border-radius:999px;border:3px solid rgba(118,88,255,.95);background:rgba(118,88,255,.22);transform:translate(-50%,-50%) scale(.8);animation:pulse .55s ease-out forwards}@keyframes pulse{to{opacity:0;transform:translate(-50%,-50%) scale(2.2)}}';
  root.appendChild(style);
  document.documentElement.appendChild(host);
  return { host, root };
}
