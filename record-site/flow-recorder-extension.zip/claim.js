globalThis.__flowTargetingClaimToken = window.name.startsWith('flow-targeting-')
  ? window.name.slice('flow-targeting-'.length)
  : '';

if (globalThis.__flowTargetingClaimToken) {
  window.name = '';
  chrome.runtime.sendMessage({
    type: 'rememberTargetingClaim',
    token: globalThis.__flowTargetingClaimToken
  }).catch(() => {});
}
